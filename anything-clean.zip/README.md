# Bus Transport App (Mobile + Web)

Monorepo structure:

apps/
  mobile/   -> React Native (Expo) mobile app
  web/      -> Web / API backend

## Run Mobile
cd apps/mobile
npm install
npx expo start

## Run Backend
cd apps/web
npm install
npm run dev

## Environment
Copy `.env.example` to `.env` and add your API keys.