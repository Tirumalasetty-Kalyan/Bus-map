import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Linking,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { router } from "expo-router";
import * as Location from "expo-location";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import {
  AlertTriangle,
  Phone,
  Shield,
  MapPin,
  Clock,
  MessageCircle,
  User,
  Siren,
  Heart,
  Flame,
  Car,
  Users,
} from "lucide-react-native";

export default function SOSScreen() {
  const insets = useSafeAreaInsets();
  const [userLocation, setUserLocation] = useState(null);
  const [userName, setUserName] = useState("");
  const [userPhone, setUserPhone] = useState("");
  const [emergencyMessage, setEmergencyMessage] = useState("");
  const [emergencyContacts, setEmergencyContacts] = useState([]);
  const [myAlerts, setMyAlerts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("emergency"); // emergency, contacts, history

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    getCurrentLocation();
    fetchEmergencyContacts();
  }, []);

  useEffect(() => {
    if (activeTab === "history" && userPhone) {
      fetchMyAlerts();
    }
  }, [activeTab, userPhone]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        Alert.alert(
          "Permission Required",
          "Location permission is required for emergency services"
        );
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      setUserLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });
    } catch (error) {
      console.error("Error getting location:", error);
    }
  };

  const fetchEmergencyContacts = async () => {
    try {
      const response = await fetch("/api/sos/contacts");
      const data = await response.json();

      if (data.success) {
        setEmergencyContacts(data.contacts);
      }
    } catch (error) {
      console.error("Error fetching emergency contacts:", error);
    }
  };

  const fetchMyAlerts = async () => {
    if (!userPhone) return;

    try {
      const response = await fetch(`/api/sos/alert?phone=${encodeURIComponent(userPhone)}`);
      const data = await response.json();

      if (data.success) {
        setMyAlerts(data.alerts);
      }
    } catch (error) {
      console.error("Error fetching alerts:", error);
    }
  };

  const sendSOSAlert = async (alertType = "Emergency") => {
    if (!userPhone || !userLocation) {
      Alert.alert("Error", "Phone number and location are required");
      return;
    }

    try {
      setLoading(true);
      const response = await fetch("/api/sos/alert", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userName,
          userPhone,
          latitude: userLocation.latitude,
          longitude: userLocation.longitude,
          locationAddress: `Lat: ${userLocation.latitude.toFixed(6)}, Lng: ${userLocation.longitude.toFixed(6)}`,
          alertType,
          message: emergencyMessage || `Emergency alert from ${userName || 'User'}`,
        }),
      });

      const data = await response.json();

      if (data.success) {
        Alert.alert(
          "SOS Alert Sent",
          "Your emergency alert has been sent successfully. Help is on the way!",
          [
            {
              text: "OK",
              onPress: () => {
                setActiveTab("history");
                fetchMyAlerts();
              },
            },
          ]
        );
      } else {
        Alert.alert("Error", data.error);
      }
    } catch (error) {
      console.error("Error sending SOS alert:", error);
      Alert.alert("Error", "Failed to send SOS alert");
    } finally {
      setLoading(false);
    }
  };

  const callEmergency = (number) => {
    Linking.openURL(`tel:${number}`);
  };

  const getContactIcon = (type) => {
    switch (type.toLowerCase()) {
      case "police":
        return Shield;
      case "ambulance":
        return Heart;
      case "fire":
        return Flame;
      case "traffic police":
        return Car;
      case "women helpline":
        return Users;
      default:
        return Phone;
    }
  };

  const getContactColor = (type) => {
    switch (type.toLowerCase()) {
      case "police":
        return "#1e40af";
      case "ambulance":
        return "#dc2626";
      case "fire":
        return "#ea580c";
      case "traffic police":
        return "#7c3aed";
      case "women helpline":
        return "#be185d";
      default:
        return "#374151";
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#F2F4F5",
        paddingTop: insets.top,
      }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          backgroundColor: "#ffffff",
          paddingHorizontal: 20,
          paddingBottom: 20,
          paddingTop: 16,
        }}
      >
        <Text
          style={{
            fontFamily: "Poppins_600SemiBold",
            fontSize: 24,
            color: "#202226",
            marginBottom: 4,
          }}
        >
          Find Me - SOS
        </Text>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
            marginBottom: 16,
          }}
        >
          Emergency assistance when you need it
        </Text>

        {/* Tab Navigation */}
        <View
          style={{
            flexDirection: "row",
            backgroundColor: "#F8F9FA",
            borderRadius: 8,
            padding: 4,
          }}
        >
          <TouchableOpacity
            style={{
              flex: 1,
              backgroundColor: activeTab === "emergency" ? "#dc2626" : "transparent",
              borderRadius: 6,
              paddingVertical: 12,
              alignItems: "center",
            }}
            onPress={() => setActiveTab("emergency")}
          >
            <Text
              style={{
                fontFamily: "Poppins_500Medium",
                fontSize: 14,
                color: activeTab === "emergency" ? "#ffffff" : "#7e8493",
              }}
            >
              Emergency
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              flex: 1,
              backgroundColor: activeTab === "contacts" ? "#dc2626" : "transparent",
              borderRadius: 6,
              paddingVertical: 12,
              alignItems: "center",
            }}
            onPress={() => setActiveTab("contacts")}
          >
            <Text
              style={{
                fontFamily: "Poppins_500Medium",
                fontSize: 14,
                color: activeTab === "contacts" ? "#ffffff" : "#7e8493",
              }}
            >
              Contacts
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              flex: 1,
              backgroundColor: activeTab === "history" ? "#dc2626" : "transparent",
              borderRadius: 6,
              paddingVertical: 12,
              alignItems: "center",
            }}
            onPress={() => setActiveTab("history")}
          >
            <Text
              style={{
                fontFamily: "Poppins_500Medium",
                fontSize: 14,
                color: activeTab === "history" ? "#ffffff" : "#7e8493",
              }}
            >
              History
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: insets.bottom + 100,
        }}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === "emergency" && (
          <>
            {/* Quick Emergency Buttons */}
            <View
              style={{
                backgroundColor: "#ffffff",
                borderRadius: 12,
                borderWidth: 1,
                borderColor: "#E5E8EC",
                padding: 20,
                marginBottom: 20,
              }}
            >
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 18,
                  color: "#202226",
                  marginBottom: 16,
                }}
              >
                Quick Emergency Actions
              </Text>

              <View style={{ flexDirection: "row", gap: 12, marginBottom: 16 }}>
                <TouchableOpacity
                  style={{
                    flex: 1,
                    backgroundColor: "#dc2626",
                    borderRadius: 8,
                    paddingVertical: 16,
                    alignItems: "center",
                    gap: 8,
                  }}
                  onPress={() => callEmergency("100")}
                >
                  <Shield size={24} color="#ffffff" />
                  <Text
                    style={{
                      fontFamily: "Poppins_500Medium",
                      fontSize: 12,
                      color: "#ffffff",
                      textAlign: "center",
                    }}
                  >
                    Police{"\n"}(100)
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={{
                    flex: 1,
                    backgroundColor: "#16a34a",
                    borderRadius: 8,
                    paddingVertical: 16,
                    alignItems: "center",
                    gap: 8,
                  }}
                  onPress={() => callEmergency("108")}
                >
                  <Heart size={24} color="#ffffff" />
                  <Text
                    style={{
                      fontFamily: "Poppins_500Medium",
                      fontSize: 12,
                      color: "#ffffff",
                      textAlign: "center",
                    }}
                  >
                    Ambulance{"\n"}(108)
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={{
                    flex: 1,
                    backgroundColor: "#ea580c",
                    borderRadius: 8,
                    paddingVertical: 16,
                    alignItems: "center",
                    gap: 8,
                  }}
                  onPress={() => callEmergency("101")}
                >
                  <Flame size={24} color="#ffffff" />
                  <Text
                    style={{
                      fontFamily: "Poppins_500Medium",
                      fontSize: 12,
                      color: "#ffffff",
                      textAlign: "center",
                    }}
                  >
                    Fire{"\n"}(101)
                  </Text>
                </TouchableOpacity>
              </View>

              <TouchableOpacity
                style={{
                  backgroundColor: "#7c3aed",
                  borderRadius: 8,
                  paddingVertical: 12,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                }}
                onPress={() => callEmergency("1091")}
              >
                <Users size={20} color="#ffffff" />
                <Text
                  style={{
                    fontFamily: "Poppins_500Medium",
                    fontSize: 14,
                    color: "#ffffff",
                  }}
                >
                  Women Helpline (1091)
                </Text>
              </TouchableOpacity>
            </View>

            {/* SOS Alert Form */}
            <View
              style={{
                backgroundColor: "#ffffff",
                borderRadius: 12,
                borderWidth: 1,
                borderColor: "#E5E8EC",
                padding: 20,
                marginBottom: 20,
              }}
            >
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 18,
                  color: "#202226",
                  marginBottom: 16,
                }}
              >
                Send SOS Alert
              </Text>

              <View style={{ marginBottom: 16 }}>
                <Text
                  style={{
                    fontFamily: "Poppins_400Regular",
                    fontSize: 14,
                    color: "#7e8493",
                    marginBottom: 8,
                  }}
                >
                  Your Name
                </Text>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    backgroundColor: "#F8F9FA",
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: "#E5E8EC",
                    paddingHorizontal: 16,
                    paddingVertical: 12,
                  }}
                >
                  <User size={20} color="#7e8493" />
                  <TextInput
                    style={{
                      flex: 1,
                      marginLeft: 12,
                      fontFamily: "Poppins_400Regular",
                      fontSize: 16,
                      color: "#202226",
                    }}
                    placeholder="Enter your name"
                    placeholderTextColor="#7e8493"
                    value={userName}
                    onChangeText={setUserName}
                  />
                </View>
              </View>

              <View style={{ marginBottom: 16 }}>
                <Text
                  style={{
                    fontFamily: "Poppins_400Regular",
                    fontSize: 14,
                    color: "#7e8493",
                    marginBottom: 8,
                  }}
                >
                  Phone Number
                </Text>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    backgroundColor: "#F8F9FA",
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: "#E5E8EC",
                    paddingHorizontal: 16,
                    paddingVertical: 12,
                  }}
                >
                  <Phone size={20} color="#7e8493" />
                  <TextInput
                    style={{
                      flex: 1,
                      marginLeft: 12,
                      fontFamily: "Poppins_400Regular",
                      fontSize: 16,
                      color: "#202226",
                    }}
                    placeholder="Enter your phone number"
                    placeholderTextColor="#7e8493"
                    value={userPhone}
                    onChangeText={setUserPhone}
                    keyboardType="phone-pad"
                  />
                </View>
              </View>

              <View style={{ marginBottom: 16 }}>
                <Text
                  style={{
                    fontFamily: "Poppins_400Regular",
                    fontSize: 14,
                    color: "#7e8493",
                    marginBottom: 8,
                  }}
                >
                  Current Location
                </Text>
                <View
                  style={{
                    backgroundColor: "#F8F9FA",
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: "#E5E8EC",
                    padding: 12,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 8,
                  }}
                >
                  <MapPin size={16} color="#7e8493" />
                  <Text
                    style={{
                      fontFamily: "Poppins_400Regular",
                      fontSize: 14,
                      color: userLocation ? "#202226" : "#7e8493",
                      flex: 1,
                    }}
                  >
                    {userLocation
                      ? `${userLocation.latitude.toFixed(6)}, ${userLocation.longitude.toFixed(6)}`
                      : "Getting location..."}
                  </Text>
                  <TouchableOpacity onPress={getCurrentLocation}>
                    <Text
                      style={{
                        fontFamily: "Poppins_500Medium",
                        fontSize: 12,
                        color: "#004a53",
                      }}
                    >
                      Refresh
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={{ marginBottom: 20 }}>
                <Text
                  style={{
                    fontFamily: "Poppins_400Regular",
                    fontSize: 14,
                    color: "#7e8493",
                    marginBottom: 8,
                  }}
                >
                  Emergency Message (Optional)
                </Text>
                <View
                  style={{
                    backgroundColor: "#F8F9FA",
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: "#E5E8EC",
                    padding: 12,
                  }}
                >
                  <TextInput
                    style={{
                      fontFamily: "Poppins_400Regular",
                      fontSize: 14,
                      color: "#202226",
                      minHeight: 80,
                      textAlignVertical: "top",
                    }}
                    placeholder="Describe your emergency situation..."
                    placeholderTextColor="#7e8493"
                    value={emergencyMessage}
                    onChangeText={setEmergencyMessage}
                    multiline
                  />
                </View>
              </View>

              <TouchableOpacity
                style={{
                  backgroundColor: "#dc2626",
                  borderRadius: 8,
                  paddingVertical: 16,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                }}
                onPress={() => sendSOSAlert()}
                disabled={loading}
              >
                <Siren size={20} color="#ffffff" />
                <Text
                  style={{
                    fontFamily: "Poppins_600SemiBold",
                    fontSize: 16,
                    color: "#ffffff",
                  }}
                >
                  {loading ? "Sending..." : "SEND SOS ALERT"}
                </Text>
              </TouchableOpacity>
            </View>
          </>
        )}

        {activeTab === "contacts" && (
          <View
            style={{
              backgroundColor: "#ffffff",
              borderRadius: 12,
              borderWidth: 1,
              borderColor: "#E5E8EC",
              padding: 20,
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins_500Medium",
                fontSize: 18,
                color: "#202226",
                marginBottom: 16,
              }}
            >
              Emergency Contacts
            </Text>

            {emergencyContacts.map((contact) => {
              const IconComponent = getContactIcon(contact.contact_type);
              const iconColor = getContactColor(contact.contact_type);

              return (
                <TouchableOpacity
                  key={contact.id}
                  style={{
                    backgroundColor: "#F8F9FA",
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: "#E5E8EC",
                    padding: 16,
                    marginBottom: 12,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                  onPress={() => callEmergency(contact.phone_number)}
                >
                  <View
                    style={{
                      width: 48,
                      height: 48,
                      borderRadius: 24,
                      backgroundColor: iconColor,
                      alignItems: "center",
                      justifyContent: "center",
                      marginRight: 16,
                    }}
                  >
                    <IconComponent size={24} color="#ffffff" />
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontFamily: "Poppins_600SemiBold",
                        fontSize: 16,
                        color: "#202226",
                        marginBottom: 2,
                      }}
                    >
                      {contact.name}
                    </Text>
                    <Text
                      style={{
                        fontFamily: "Poppins_400Regular",
                        fontSize: 14,
                        color: "#7e8493",
                        marginBottom: 2,
                      }}
                    >
                      {contact.contact_type}
                    </Text>
                    <Text
                      style={{
                        fontFamily: "Poppins_500Medium",
                        fontSize: 14,
                        color: iconColor,
                      }}
                    >
                      {contact.phone_number}
                    </Text>
                  </View>

                  <Phone size={20} color="#7e8493" />
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {activeTab === "history" && (
          <View
            style={{
              backgroundColor: "#ffffff",
              borderRadius: 12,
              borderWidth: 1,
              borderColor: "#E5E8EC",
              padding: 20,
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins_500Medium",
                fontSize: 18,
                color: "#202226",
                marginBottom: 16,
              }}
            >
              My SOS History
            </Text>

            {!userPhone ? (
              <View style={{ alignItems: "center", paddingVertical: 40 }}>
                <Text
                  style={{
                    fontFamily: "Poppins_400Regular",
                    fontSize: 16,
                    color: "#7e8493",
                    textAlign: "center",
                  }}
                >
                  Enter your phone number in the emergency tab to view your SOS history
                </Text>
              </View>
            ) : myAlerts.length === 0 ? (
              <View style={{ alignItems: "center", paddingVertical: 40 }}>
                <AlertTriangle size={48} color="#7e8493" />
                <Text
                  style={{
                    fontFamily: "Poppins_500Medium",
                    fontSize: 16,
                    color: "#202226",
                    marginTop: 16,
                    marginBottom: 8,
                  }}
                >
                  No SOS alerts found
                </Text>
                <Text
                  style={{
                    fontFamily: "Poppins_400Regular",
                    fontSize: 14,
                    color: "#7e8493",
                    textAlign: "center",
                  }}
                >
                  Your emergency alerts will appear here
                </Text>
              </View>
            ) : (
              myAlerts.map((alert) => (
                <View
                  key={alert.id}
                  style={{
                    backgroundColor: "#F8F9FA",
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: "#E5E8EC",
                    padding: 16,
                    marginBottom: 12,
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "flex-start",
                      marginBottom: 8,
                    }}
                  >
                    <Text
                      style={{
                        fontFamily: "Poppins_600SemiBold",
                        fontSize: 16,
                        color: "#dc2626",
                      }}
                    >
                      {alert.alert_type}
                    </Text>
                    <View
                      style={{
                        backgroundColor:
                          alert.status === "Active" ? "#fef3c7" : "#dcfce7",
                        borderRadius: 6,
                        paddingHorizontal: 8,
                        paddingVertical: 4,
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "Poppins_500Medium",
                          fontSize: 12,
                          color:
                            alert.status === "Active" ? "#d97706" : "#16a34a",
                        }}
                      >
                        {alert.status}
                      </Text>
                    </View>
                  </View>

                  {alert.message && (
                    <Text
                      style={{
                        fontFamily: "Poppins_400Regular",
                        fontSize: 14,
                        color: "#202226",
                        marginBottom: 8,
                      }}
                    >
                      {alert.message}
                    </Text>
                  )}

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 4,
                      marginBottom: 4,
                    }}
                  >
                    <MapPin size={12} color="#7e8493" />
                    <Text
                      style={{
                        fontFamily: "Poppins_400Regular",
                        fontSize: 12,
                        color: "#7e8493",
                        flex: 1,
                      }}
                    >
                      {alert.location_address || `${alert.latitude}, ${alert.longitude}`}
                    </Text>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    <Clock size={12} color="#7e8493" />
                    <Text
                      style={{
                        fontFamily: "Poppins_400Regular",
                        fontSize: 12,
                        color: "#7e8493",
                      }}
                    >
                      {new Date(alert.created_at).toLocaleString()}
                    </Text>
                  </View>
                </View>
              ))
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}