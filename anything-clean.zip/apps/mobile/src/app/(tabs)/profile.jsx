import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Linking,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { router } from "expo-router";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import {
  User,
  Phone,
  Mail,
  MapPin,
  Settings,
  HelpCircle,
  Shield,
  Star,
  Heart,
  ExternalLink,
  Info,
  FileText,
  MessageCircle,
  Share2,
  Bus,
  AlertTriangle,
  Ticket,
} from "lucide-react-native";

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  const handleFeaturePress = (feature) => {
    switch (feature) {
      case "map":
        router.push("/(tabs)/map");
        break;
      case "tickets":
        router.push("/(tabs)/tickets");
        break;
      case "sos":
        router.push("/(tabs)/sos");
        break;
      case "feedback":
        Alert.alert(
          "Feedback",
          "Thank you for using Find Me! Your feedback helps us improve.",
          [
            {
              text: "Rate App",
              onPress: () => {
                // Open app store for rating
                Alert.alert("Rating", "Feature coming soon!");
              },
            },
            { text: "Cancel", style: "cancel" },
          ]
        );
        break;
      case "share":
        Alert.alert(
          "Share Find Me",
          "Share this amazing transport tracking app with your friends!",
          [
            {
              text: "Share",
              onPress: () => {
                Alert.alert("Share", "Feature coming soon!");
              },
            },
            { text: "Cancel", style: "cancel" },
          ]
        );
        break;
      case "help":
        Alert.alert(
          "Help & Support",
          "Need help using Find Me? Contact our support team or check our FAQ.",
          [
            {
              text: "Call Support",
              onPress: () => Linking.openURL("tel:+911234567890"),
            },
            {
              text: "Email Support",
              onPress: () => Linking.openURL("mailto:support@findme.com"),
            },
            { text: "Cancel", style: "cancel" },
          ]
        );
        break;
      case "about":
        Alert.alert(
          "About Find Me",
          "Find Me is your comprehensive transport tracking app for India. Track buses, book tickets, and stay safe with our SOS features.\n\nVersion 1.0.0\nDeveloped with ❤️ for safer travel",
          [{ text: "OK" }]
        );
        break;
      case "privacy":
        Alert.alert(
          "Privacy Policy",
          "Your privacy is important to us. Find Me collects location data to provide nearby bus stops and enable emergency features. We never share your personal information without consent.",
          [{ text: "OK" }]
        );
        break;
      case "terms":
        Alert.alert(
          "Terms of Service",
          "By using Find Me, you agree to our terms of service. The app is provided as-is for informational purposes. Always verify bus schedules and routes independently.",
          [{ text: "OK" }]
        );
        break;
      default:
        Alert.alert("Coming Soon", "This feature is coming soon!");
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#F2F4F5",
        paddingTop: insets.top,
      }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          backgroundColor: "#ffffff",
          paddingHorizontal: 20,
          paddingBottom: 20,
          paddingTop: 16,
        }}
      >
        <Text
          style={{
            fontFamily: "Poppins_600SemiBold",
            fontSize: 24,
            color: "#202226",
            marginBottom: 4,
          }}
        >
          Find Me - Profile
        </Text>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
          }}
        >
          Manage your account and app preferences
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: insets.bottom + 100,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* App Features */}
        <View
          style={{
            backgroundColor: "#ffffff",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            padding: 20,
            marginBottom: 20,
          }}
        >
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 18,
              color: "#202226",
              marginBottom: 16,
            }}
          >
            App Features
          </Text>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
            onPress={() => handleFeaturePress("map")}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: "#004a53",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 16,
              }}
            >
              <MapPin size={20} color="#ffffff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Live Bus Tracking
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Track buses in real-time on India map
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
            onPress={() => handleFeaturePress("tickets")}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: "#16a34a",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 16,
              }}
            >
              <Ticket size={20} color="#ffffff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Ticket Booking
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Book bus tickets easily and quickly
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
            }}
            onPress={() => handleFeaturePress("sos")}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: "#dc2626",
                alignItems: "center",
                justifyContent: "center",
                marginRight: 16,
              }}
            >
              <AlertTriangle size={20} color="#ffffff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                SOS Emergency
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Emergency assistance when you need it
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>
        </View>

        {/* App Information */}
        <View
          style={{
            backgroundColor: "#ffffff",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            padding: 20,
            marginBottom: 20,
          }}
        >
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 18,
              color: "#202226",
              marginBottom: 16,
            }}
          >
            App Information
          </Text>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
          >
            <Bus size={20} color="#7e8493" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Transport Coverage
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Major cities across India
              </Text>
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
          >
            <MapPin size={20} color="#7e8493" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Live Tracking
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Real-time bus locations and delays
              </Text>
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
            }}
          >
            <Shield size={20} color="#7e8493" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Safety Features
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Emergency contacts and SOS alerts
              </Text>
            </View>
          </View>
        </View>

        {/* Support & Feedback */}
        <View
          style={{
            backgroundColor: "#ffffff",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            padding: 20,
            marginBottom: 20,
          }}
        >
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 18,
              color: "#202226",
              marginBottom: 16,
            }}
          >
            Support & Feedback
          </Text>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
            onPress={() => handleFeaturePress("feedback")}
          >
            <Star size={20} color="#ea580c" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Rate & Review
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Help us improve Find Me
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
            onPress={() => handleFeaturePress("share")}
          >
            <Share2 size={20} color="#16a34a" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Share App
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Tell your friends about Find Me
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
            }}
            onPress={() => handleFeaturePress("help")}
          >
            <HelpCircle size={20} color="#7c3aed" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Help & Support
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Get help and contact support
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>
        </View>

        {/* Legal & Privacy */}
        <View
          style={{
            backgroundColor: "#ffffff",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            padding: 20,
            marginBottom: 20,
          }}
        >
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 18,
              color: "#202226",
              marginBottom: 16,
            }}
          >
            Legal & Privacy
          </Text>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
            onPress={() => handleFeaturePress("about")}
          >
            <Info size={20} color="#004a53" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                About Find Me
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                App version and information
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: "#F8F9FA",
            }}
            onPress={() => handleFeaturePress("privacy")}
          >
            <Shield size={20} color="#16a34a" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Privacy Policy
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                How we protect your data
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 12,
            }}
            onPress={() => handleFeaturePress("terms")}
          >
            <FileText size={20} color="#ea580c" style={{ marginRight: 16 }} />
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 16,
                  color: "#202226",
                }}
              >
                Terms of Service
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Terms and conditions of use
              </Text>
            </View>
            <ExternalLink size={16} color="#7e8493" />
          </TouchableOpacity>
        </View>

        {/* App Credits */}
        <View
          style={{
            backgroundColor: "#ffffff",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            padding: 20,
            marginBottom: 20,
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: 60,
              height: 60,
              borderRadius: 30,
              backgroundColor: "#004a53",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 16,
            }}
          >
            <Bus size={30} color="#ffffff" />
          </View>
          
          <Text
            style={{
              fontFamily: "Poppins_600SemiBold",
              fontSize: 20,
              color: "#202226",
              marginBottom: 8,
            }}
          >
            Find Me
          </Text>
          
          <Text
            style={{
              fontFamily: "Poppins_400Regular",
              fontSize: 14,
              color: "#7e8493",
              textAlign: "center",
              marginBottom: 16,
            }}
          >
            Your trusted companion for safe and efficient travel across India
          </Text>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 12,
                color: "#7e8493",
              }}
            >
              Made with
            </Text>
            <Heart size={12} color="#dc2626" />
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 12,
                color: "#7e8493",
              }}
            >
              for safer travel
            </Text>
          </View>

          <Text
            style={{
              fontFamily: "Poppins_400Regular",
              fontSize: 10,
              color: "#7e8493",
              marginTop: 8,
            }}
          >
            Version 1.0.0
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}