import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
  Linking,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { router } from "expo-router";
import MapView, {
  PROVIDER_GOOGLE,
  Marker,
  Circle,
  Callout,
} from "react-native-maps";
import * as Location from "expo-location";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";
import {
  Search,
  Navigation,
  MapPin,
  Bus,
  Clock,
  AlertTriangle,
  RefreshCw,
  Phone,
  Ticket,
  Target,
  Locate,
} from "lucide-react-native";

const indiaRegion = {
  latitude: 20.5937,
  longitude: 78.9629,
  latitudeDelta: 30,
  longitudeDelta: 30,
};

export default function MapScreen() {
  const insets = useSafeAreaInsets();
  const mapRef = useRef(null);
  const [userLocation, setUserLocation] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [nearbyStops, setNearbyStops] = useState([]);
  const [selectedStop, setSelectedStop] = useState(null);
  const [loading, setLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(true);
  const [showBottomSheet, setShowBottomSheet] = useState(false);
  const [radius, setRadius] = useState(5); // Default 5km radius
  const [mapReady, setMapReady] = useState(false);

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  useEffect(() => {
    requestLocationPermission();
  }, []);

  useEffect(() => {
    if (userLocation && mapReady) {
      fetchNearbyStops(userLocation.latitude, userLocation.longitude);
    }
  }, [userLocation, radius, mapReady]);

  const requestLocationPermission = async () => {
    try {
      setLocationLoading(true);

      // Request foreground location permission
      const { status } = await Location.requestForegroundPermissionsAsync();

      if (status !== "granted") {
        Alert.alert(
          "Location Access Required",
          "Find Me needs location access to show nearby bus stops and provide emergency services. Please enable location access in settings.",
          [
            { text: "Cancel", style: "cancel" },
            { text: "Open Settings", onPress: () => Linking.openSettings() },
          ],
        );
        setLocationLoading(false);
        return;
      }

      // Get current location with high accuracy
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
        timeout: 15000,
        maximumAge: 10000,
      });

      const userCoords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(userCoords);
      setLocationLoading(false);

      // Auto-focus on user location
      if (mapRef.current) {
        mapRef.current.animateToRegion(
          {
            ...userCoords,
            latitudeDelta: 0.05,
            longitudeDelta: 0.05,
          },
          1000,
        );
      }
    } catch (error) {
      console.error("Error getting location:", error);
      setLocationLoading(false);
      Alert.alert(
        "Location Error",
        "Could not get your current location. Please check your GPS settings and try again.",
        [
          { text: "Retry", onPress: requestLocationPermission },
          { text: "Cancel", style: "cancel" },
        ],
      );
    }
  };

  const fetchNearbyStops = async (lat, lng) => {
    try {
      setLoading(true);
      const response = await fetch(
        `/api/bus-stops/nearby?latitude=${lat}&longitude=${lng}&radius=${radius}`,
      );
      const data = await response.json();

      if (data.success) {
        setNearbyStops(data.stops);
        console.log(`Found ${data.stops.length} bus stops within ${radius}km`);
      } else {
        console.error("Error fetching nearby stops:", data.error);
        Alert.alert(
          "Error",
          "Could not fetch nearby bus stops. Please try again.",
        );
      }
    } catch (error) {
      console.error("Error fetching nearby stops:", error);
      Alert.alert(
        "Network Error",
        "Please check your internet connection and try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleStopPress = (stop) => {
    setSelectedStop(stop);
    setShowBottomSheet(true);

    // Animate to selected stop
    if (mapRef.current) {
      mapRef.current.animateToRegion(
        {
          latitude: parseFloat(stop.latitude),
          longitude: parseFloat(stop.longitude),
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        },
        500,
      );
    }
  };

  const handleBookTicketFromStop = (stop) => {
    // Navigate to tickets screen and pre-fill the from location
    router.push({
      pathname: "/(tabs)/tickets",
      params: {
        fromLocation: stop.name,
        fromStopId: stop.id,
      },
    });
  };

  const handleEmergency = () => {
    router.push("/(tabs)/sos");
  };

  const handleCallEmergency = (number) => {
    Alert.alert("Emergency Call", `Call ${number}?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Call", onPress: () => Linking.openURL(`tel:${number}`) },
    ]);
  };

  const handleMyLocation = () => {
    if (userLocation && mapRef.current) {
      mapRef.current.animateToRegion(
        {
          ...userLocation,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        },
        1000,
      );
    } else {
      requestLocationPermission();
    }
  };

  const onMapReady = () => {
    setMapReady(true);
  };

  if (!fontsLoaded) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#004a53" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <StatusBar style="dark" />

      {/* Map */}
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={{ flex: 1 }}
        initialRegion={indiaRegion}
        showsUserLocation={true}
        showsMyLocationButton={false}
        showsCompass={true}
        toolbarEnabled={false}
        loadingEnabled={true}
        onMapReady={onMapReady}
        mapType="standard"
        followsUserLocation={false}
      >
        {/* User location accuracy circle */}
        {userLocation && (
          <Circle
            center={userLocation}
            radius={radius * 1000} // Convert km to meters
            strokeColor="rgba(0, 74, 83, 0.3)"
            fillColor="rgba(0, 74, 83, 0.1)"
            strokeWidth={2}
          />
        )}

        {/* Bus stop markers */}
        {nearbyStops.map((stop) => (
          <Marker
            key={stop.id}
            coordinate={{
              latitude: parseFloat(stop.latitude),
              longitude: parseFloat(stop.longitude),
            }}
            onPress={() => handleStopPress(stop)}
          >
            <View
              style={{
                backgroundColor: "#004a53",
                borderRadius: 20,
                padding: 8,
                borderWidth: 2,
                borderColor: "#ffffff",
                alignItems: "center",
                justifyContent: "center",
                minWidth: 40,
                minHeight: 40,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.3,
                shadowRadius: 3,
                elevation: 5,
              }}
            >
              <Bus size={16} color="#ffffff" />
              {stop.routes && stop.routes.length > 0 && (
                <Text
                  style={{
                    color: "#ffffff",
                    fontSize: 8,
                    fontFamily: "Poppins_600SemiBold",
                    marginTop: 2,
                  }}
                >
                  {stop.routes.length}
                </Text>
              )}
            </View>

            <Callout tooltip={false}>
              <View
                style={{
                  backgroundColor: "#ffffff",
                  padding: 8,
                  borderRadius: 8,
                  minWidth: 120,
                  alignItems: "center",
                }}
              >
                <Text
                  style={{
                    fontFamily: "Poppins_600SemiBold",
                    fontSize: 12,
                    color: "#202226",
                    textAlign: "center",
                  }}
                >
                  {stop.name}
                </Text>
                <Text
                  style={{
                    fontFamily: "Poppins_400Regular",
                    fontSize: 10,
                    color: "#7e8493",
                    textAlign: "center",
                  }}
                >
                  {stop.distance_km?.toFixed(1)} km away
                </Text>
                {stop.routes && stop.routes.length > 0 && (
                  <Text
                    style={{
                      fontFamily: "Poppins_400Regular",
                      fontSize: 10,
                      color: "#004a53",
                      textAlign: "center",
                    }}
                  >
                    {stop.routes.length} routes available
                  </Text>
                )}
              </View>
            </Callout>
          </Marker>
        ))}
      </MapView>

      {/* Header with Location Status */}
      <View
        style={{
          position: "absolute",
          top: insets.top + 10,
          left: 20,
          right: 20,
          backgroundColor: "#ffffff",
          borderRadius: 12,
          padding: 16,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        }}
      >
        {locationLoading ? (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <ActivityIndicator
              size="small"
              color="#004a53"
              style={{ marginRight: 8 }}
            />
            <Text
              style={{
                fontFamily: "Poppins_500Medium",
                fontSize: 14,
                color: "#004a53",
              }}
            >
              Getting your location...
            </Text>
          </View>
        ) : userLocation ? (
          <View>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 8,
              }}
            >
              <Target size={16} color="#16a34a" style={{ marginRight: 8 }} />
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 14,
                  color: "#16a34a",
                  flex: 1,
                }}
              >
                Location Found - {nearbyStops.length} stops nearby
              </Text>
              {loading && <ActivityIndicator size="small" color="#004a53" />}
            </View>

            {/* Search Bar */}
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Search size={18} color="#7e8493" />
              <TextInput
                style={{
                  flex: 1,
                  marginLeft: 12,
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#202226",
                }}
                placeholder="Search bus stops, routes..."
                placeholderTextColor="#7e8493"
                value={searchQuery}
                onChangeText={setSearchQuery}
              />
            </View>
          </View>
        ) : (
          <TouchableOpacity
            onPress={requestLocationPermission}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <AlertTriangle
              size={16}
              color="#dc2626"
              style={{ marginRight: 8 }}
            />
            <Text
              style={{
                fontFamily: "Poppins_500Medium",
                fontSize: 14,
                color: "#dc2626",
              }}
            >
              Tap to enable location access
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Controls */}
      <View
        style={{
          position: "absolute",
          bottom: showBottomSheet ? 320 : 120,
          right: 20,
          gap: 12,
        }}
      >
        {/* My Location Button */}
        <TouchableOpacity
          style={{
            backgroundColor: userLocation ? "#16a34a" : "#ffffff",
            width: 50,
            height: 50,
            borderRadius: 25,
            alignItems: "center",
            justifyContent: "center",
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
          onPress={handleMyLocation}
        >
          <Locate size={24} color={userLocation ? "#ffffff" : "#004a53"} />
        </TouchableOpacity>

        {/* Refresh Nearby Stops */}
        <TouchableOpacity
          style={{
            backgroundColor: "#ffffff",
            width: 50,
            height: 50,
            borderRadius: 25,
            alignItems: "center",
            justifyContent: "center",
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
          onPress={() => {
            if (userLocation) {
              fetchNearbyStops(userLocation.latitude, userLocation.longitude);
            }
          }}
          disabled={!userLocation || loading}
        >
          <RefreshCw size={24} color={loading ? "#7e8493" : "#004a53"} />
        </TouchableOpacity>
      </View>

      {/* Emergency Button */}
      <TouchableOpacity
        style={{
          position: "absolute",
          top: insets.top + 120,
          right: 20,
          backgroundColor: "#dc2626",
          width: 50,
          height: 50,
          borderRadius: 25,
          alignItems: "center",
          justifyContent: "center",
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.2,
          shadowRadius: 4,
          elevation: 3,
        }}
        onPress={handleEmergency}
      >
        <AlertTriangle size={24} color="#ffffff" />
      </TouchableOpacity>

      {/* Bottom Sheet */}
      {showBottomSheet && selectedStop && (
        <View
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: "#ffffff",
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            paddingHorizontal: 20,
            paddingTop: 24,
            paddingBottom: insets.bottom + 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: -2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 5,
            maxHeight: 350,
          }}
        >
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Handle bar */}
            <View
              style={{
                width: 40,
                height: 4,
                backgroundColor: "#E5E8EC",
                borderRadius: 2,
                alignSelf: "center",
                marginBottom: 20,
              }}
            />

            {/* Stop Info */}
            <View style={{ marginBottom: 20 }}>
              <Text
                style={{
                  fontFamily: "Poppins_600SemiBold",
                  fontSize: 18,
                  color: "#202226",
                  marginBottom: 4,
                }}
              >
                {selectedStop.name}
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                  marginBottom: 8,
                }}
              >
                {selectedStop.city}, {selectedStop.state} •{" "}
                {selectedStop.stop_code}
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 12,
                  color: "#7e8493",
                }}
              >
                📍 {selectedStop.distance_km?.toFixed(1)} km from your location
              </Text>
            </View>

            {/* Routes */}
            {selectedStop.routes && selectedStop.routes.length > 0 && (
              <View style={{ marginBottom: 20 }}>
                <Text
                  style={{
                    fontFamily: "Poppins_500Medium",
                    fontSize: 16,
                    color: "#202226",
                    marginBottom: 12,
                  }}
                >
                  Available Routes ({selectedStop.routes.length})
                </Text>

                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  <View style={{ flexDirection: "row", gap: 12 }}>
                    {selectedStop.routes.map((route, index) => (
                      <View
                        key={index}
                        style={{
                          backgroundColor: "#F8F9FA",
                          borderRadius: 8,
                          borderWidth: 1,
                          borderColor: "#E5E8EC",
                          padding: 12,
                          minWidth: 100,
                        }}
                      >
                        <Text
                          style={{
                            fontFamily: "Poppins_600SemiBold",
                            fontSize: 16,
                            color: "#004a53",
                            marginBottom: 4,
                          }}
                        >
                          {route.route_number}
                        </Text>
                        <Text
                          style={{
                            fontFamily: "Poppins_400Regular",
                            fontSize: 12,
                            color: "#7e8493",
                          }}
                        >
                          {route.bus_type}
                        </Text>
                      </View>
                    ))}
                  </View>
                </ScrollView>
              </View>
            )}

            {/* Live Buses */}
            {selectedStop.liveBuses && selectedStop.liveBuses.length > 0 && (
              <View style={{ marginBottom: 20 }}>
                <Text
                  style={{
                    fontFamily: "Poppins_500Medium",
                    fontSize: 16,
                    color: "#202226",
                    marginBottom: 12,
                  }}
                >
                  🚌 Live Buses
                </Text>

                {selectedStop.liveBuses.map((bus, index) => (
                  <View
                    key={index}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                      backgroundColor: "#F8F9FA",
                      borderRadius: 8,
                      padding: 12,
                      marginBottom: 8,
                    }}
                  >
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontFamily: "Poppins_500Medium",
                          fontSize: 14,
                          color: "#202226",
                        }}
                      >
                        {bus.route_number} • {bus.bus_number}
                      </Text>
                      <Text
                        style={{
                          fontFamily: "Poppins_400Regular",
                          fontSize: 12,
                          color: "#7e8493",
                        }}
                      >
                        {bus.status}
                      </Text>
                    </View>
                    <View style={{ alignItems: "flex-end" }}>
                      <View
                        style={{
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 4,
                        }}
                      >
                        <Clock size={12} color="#7e8493" />
                        <Text
                          style={{
                            fontFamily: "Poppins_400Regular",
                            fontSize: 12,
                            color: "#7e8493",
                          }}
                        >
                          {bus.estimated_arrival}
                        </Text>
                      </View>
                      {bus.delay_minutes > 0 && (
                        <Text
                          style={{
                            fontFamily: "Poppins_400Regular",
                            fontSize: 10,
                            color: "#dc2626",
                          }}
                        >
                          +{bus.delay_minutes}min delay
                        </Text>
                      )}
                    </View>
                  </View>
                ))}
              </View>
            )}

            {/* Actions */}
            <View style={{ flexDirection: "row", gap: 12 }}>
              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor: "#004a53",
                  borderRadius: 8,
                  paddingVertical: 12,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                }}
                onPress={() => handleBookTicketFromStop(selectedStop)}
              >
                <Ticket size={16} color="#ffffff" />
                <Text
                  style={{
                    fontFamily: "Poppins_500Medium",
                    fontSize: 14,
                    color: "#ffffff",
                  }}
                >
                  Book Ticket
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  backgroundColor: "#F8F9FA",
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: "#E5E8EC",
                  paddingHorizontal: 12,
                  paddingVertical: 12,
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onPress={() => setShowBottomSheet(false)}
              >
                <MapPin size={20} color="#7e8493" />
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      )}

      {/* Quick Emergency Actions */}
      <View
        style={{
          position: "absolute",
          bottom: insets.bottom + 20,
          left: 20,
          right: 20,
          flexDirection: "row",
          gap: 12,
        }}
      >
        <TouchableOpacity
          style={{
            flex: 1,
            backgroundColor: "#dc2626",
            borderRadius: 8,
            paddingVertical: 12,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
          onPress={() => handleCallEmergency("100")}
        >
          <Phone size={16} color="#ffffff" />
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 14,
              color: "#ffffff",
            }}
          >
            Police (100)
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={{
            flex: 1,
            backgroundColor: "#16a34a",
            borderRadius: 8,
            paddingVertical: 12,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
          onPress={() => handleCallEmergency("108")}
        >
          <Phone size={16} color="#ffffff" />
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 14,
              color: "#ffffff",
            }}
          >
            Ambulance (108)
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
