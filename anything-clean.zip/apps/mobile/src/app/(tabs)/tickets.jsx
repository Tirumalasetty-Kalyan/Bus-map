import React, { useState } from "react";
import { View, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useLocalSearchParams } from "expo-router";
import {
  useFonts,
  Poppins_400Regular,
  Poppins_500Medium,
  Poppins_600SemiBold,
  Poppins_700Bold,
} from "@expo-google-fonts/poppins";

import { useTickets } from "@/hooks/useTickets";
import { TicketsHeader } from "@/components/tickets/TicketsHeader";
import { PassengerDetailsCard } from "@/components/tickets/PassengerDetailsCard";
import { JourneyDetailsCard } from "@/components/tickets/JourneyDetailsCard";
import { AvailableRoutes } from "@/components/tickets/AvailableRoutes";
import { BookingHistory } from "@/components/tickets/BookingHistory";
import { QRCodeModal } from "@/components/tickets/QRCodeModal";

export default function TicketsScreen() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const [activeTab, setActiveTab] = useState("book"); // book, history
  const [showQRModal, setShowQRModal] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);

  const {
    fromLocation,
    setFromLocation,
    toLocation,
    setToLocation,
    journeyDate,
    setJourneyDate,
    userName,
    setUserName,
    userPhone,
    setUserPhone,
    routes,
    bookings,
    loading,
    searchRoutes,
    bookTicket,
  } = useTickets(activeTab);

  // Pre-fill from location if coming from map
  React.useEffect(() => {
    if (params.fromLocation) {
      setFromLocation(params.fromLocation);
    }
  }, [params.fromLocation]);

  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_500Medium,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });

  const handleBookTicket = async (route) => {
    const success = await bookTicket(route);
    if (success) {
      setActiveTab("history");
    }
  };

  const handleShowQR = (booking) => {
    setSelectedTicket(booking);
    setShowQRModal(true);
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#F2F4F5",
        paddingTop: insets.top,
      }}
    >
      <StatusBar style="dark" />

      <TicketsHeader activeTab={activeTab} setActiveTab={setActiveTab} />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: insets.bottom + 100,
        }}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === "book" ? (
          <>
            <PassengerDetailsCard
              userName={userName}
              setUserName={setUserName}
              userPhone={userPhone}
              setUserPhone={setUserPhone}
            />
            <JourneyDetailsCard
              fromLocation={fromLocation}
              setFromLocation={setFromLocation}
              toLocation={toLocation}
              setToLocation={setToLocation}
              journeyDate={journeyDate}
              setJourneyDate={setJourneyDate}
              onSearch={searchRoutes}
              loading={loading}
            />
            <AvailableRoutes routes={routes} onBookTicket={handleBookTicket} />
          </>
        ) : (
          <BookingHistory
            bookings={bookings}
            userPhone={userPhone}
            onShowQR={handleShowQR}
          />
        )}
      </ScrollView>

      {/* QR Code Modal */}
      <QRCodeModal
        visible={showQRModal}
        ticket={selectedTicket}
        onClose={() => setShowQRModal(false)}
      />
    </View>
  );
}
