import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { Ticket, QrCode } from "lucide-react-native";

const BookingItem = ({ booking, onShowQR }) => (
  <View
    style={{
      backgroundColor: "#F8F9FA",
      borderRadius: 8,
      borderWidth: 1,
      borderColor: "#E5E8EC",
      padding: 16,
      marginBottom: 12,
    }}
  >
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "flex-start",
        marginBottom: 8,
      }}
    >
      <View style={{ flex: 1 }}>
        <Text
          style={{
            fontFamily: "Poppins_600SemiBold",
            fontSize: 16,
            color: "#004a53",
            marginBottom: 4,
          }}
        >
          {booking.route_number} - {booking.route_name}
        </Text>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
          }}
        >
          {booking.operator_name}
        </Text>
      </View>
      <View
        style={{
          backgroundColor:
            booking.booking_status === "Confirmed" ? "#dcfce7" : "#fef3c7",
          borderRadius: 6,
          paddingHorizontal: 8,
          paddingVertical: 4,
        }}
      >
        <Text
          style={{
            fontFamily: "Poppins_500Medium",
            fontSize: 12,
            color:
              booking.booking_status === "Confirmed" ? "#16a34a" : "#d97706",
          }}
        >
          {booking.booking_status}
        </Text>
      </View>
    </View>

    <View style={{ marginBottom: 8 }}>
      <Text
        style={{
          fontFamily: "Poppins_400Regular",
          fontSize: 14,
          color: "#202226",
        }}
      >
        📍 {booking.source_stop_name} → {booking.dest_stop_name}
      </Text>
      <Text
        style={{
          fontFamily: "Poppins_400Regular",
          fontSize: 12,
          color: "#7e8493",
        }}
      >
        📅 {new Date(booking.journey_date).toLocaleDateString()} • ⏰{" "}
        {booking.journey_time}
      </Text>
    </View>

    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 12,
      }}
    >
      <Text
        style={{
          fontFamily: "Poppins_500Medium",
          fontSize: 12,
          color: "#7e8493",
        }}
      >
        🎫 {booking.ticket_number}
      </Text>
      <Text
        style={{
          fontFamily: "Poppins_700Bold",
          fontSize: 16,
          color: "#004a53",
        }}
      >
        ₹{booking.total_fare}
      </Text>
    </View>

    {/* QR Code Button */}
    <TouchableOpacity
      style={{
        backgroundColor: "#004a53",
        borderRadius: 6,
        paddingVertical: 10,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
      }}
      onPress={() => onShowQR && onShowQR(booking)}
    >
      <QrCode size={16} color="#ffffff" />
      <Text
        style={{
          fontFamily: "Poppins_500Medium",
          fontSize: 14,
          color: "#ffffff",
        }}
      >
        Show QR Code
      </Text>
    </TouchableOpacity>
  </View>
);

export function BookingHistory({ bookings, userPhone, onShowQR }) {
  return (
    <View
      style={{
        backgroundColor: "#ffffff",
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "#E5E8EC",
        padding: 20,
        marginBottom: 20,
      }}
    >
      <Text
        style={{
          fontFamily: "Poppins_500Medium",
          fontSize: 18,
          color: "#202226",
          marginBottom: 16,
        }}
      >
        🎫 My Bookings ({bookings.length})
      </Text>

      {!userPhone ? (
        <View style={{ alignItems: "center", paddingVertical: 40 }}>
          <Text
            style={{
              fontFamily: "Poppins_400Regular",
              fontSize: 16,
              color: "#7e8493",
              textAlign: "center",
            }}
          >
            Enter your phone number in the booking tab to view your tickets
          </Text>
        </View>
      ) : bookings.length === 0 ? (
        <View style={{ alignItems: "center", paddingVertical: 40 }}>
          <Ticket size={48} color="#7e8493" />
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 16,
              color: "#202226",
              marginTop: 16,
              marginBottom: 8,
            }}
          >
            No tickets found
          </Text>
          <Text
            style={{
              fontFamily: "Poppins_400Regular",
              fontSize: 14,
              color: "#7e8493",
              textAlign: "center",
            }}
          >
            Book your first ticket to see it here
          </Text>
        </View>
      ) : (
        bookings.map((booking) => (
          <BookingItem key={booking.id} booking={booking} onShowQR={onShowQR} />
        ))
      )}
    </View>
  );
}
