import React from "react";
import { View, Text, TouchableOpacity } from "react-native";

export function TicketsHeader({ activeTab, setActiveTab }) {
  return (
    <View
      style={{
        backgroundColor: "#ffffff",
        paddingHorizontal: 20,
        paddingBottom: 20,
        paddingTop: 16,
      }}
    >
      <Text
        style={{
          fontFamily: "Poppins_600SemiBold",
          fontSize: 24,
          color: "#202226",
          marginBottom: 4,
        }}
      >
        Find Me - Tickets
      </Text>
      <Text
        style={{
          fontFamily: "Poppins_400Regular",
          fontSize: 14,
          color: "#7e8493",
          marginBottom: 16,
        }}
      >
        Book your bus tickets easily
      </Text>

      {/* Tab Navigation */}
      <View
        style={{
          flexDirection: "row",
          backgroundColor: "#F8F9FA",
          borderRadius: 8,
          padding: 4,
        }}
      >
        <TouchableOpacity
          style={{
            flex: 1,
            backgroundColor: activeTab === "book" ? "#004a53" : "transparent",
            borderRadius: 6,
            paddingVertical: 12,
            alignItems: "center",
          }}
          onPress={() => setActiveTab("book")}
        >
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 14,
              color: activeTab === "book" ? "#ffffff" : "#7e8493",
            }}
          >
            Book Ticket
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            flex: 1,
            backgroundColor:
              activeTab === "history" ? "#004a53" : "transparent",
            borderRadius: 6,
            paddingVertical: 12,
            alignItems: "center",
          }}
          onPress={() => setActiveTab("history")}
        >
          <Text
            style={{
              fontFamily: "Poppins_500Medium",
              fontSize: 14,
              color: activeTab === "history" ? "#ffffff" : "#7e8493",
            }}
          >
            My Tickets
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
