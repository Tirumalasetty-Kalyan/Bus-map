import React from "react";
import { View, Text, TextInput } from "react-native";

export function PassengerDetailsCard({
  userName,
  setUserName,
  userPhone,
  setUserPhone,
}) {
  return (
    <View
      style={{
        backgroundColor: "#ffffff",
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "#E5E8EC",
        padding: 20,
        marginBottom: 20,
      }}
    >
      <Text
        style={{
          fontFamily: "Poppins_500Medium",
          fontSize: 18,
          color: "#202226",
          marginBottom: 16,
        }}
      >
        Passenger Details
      </Text>

      <View style={{ marginBottom: 16 }}>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
            marginBottom: 8,
          }}
        >
          Full Name
        </Text>
        <TextInput
          style={{
            backgroundColor: "#F8F9FA",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            paddingHorizontal: 16,
            paddingVertical: 12,
            fontFamily: "Poppins_400Regular",
            fontSize: 16,
            color: "#202226",
          }}
          placeholder="Enter your full name"
          placeholderTextColor="#7e8493"
          value={userName}
          onChangeText={setUserName}
        />
      </View>

      <View>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
            marginBottom: 8,
          }}
        >
          Phone Number
        </Text>
        <TextInput
          style={{
            backgroundColor: "#F8F9FA",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            paddingHorizontal: 16,
            paddingVertical: 12,
            fontFamily: "Poppins_400Regular",
            fontSize: 16,
            color: "#202226",
          }}
          placeholder="Enter your phone number"
          placeholderTextColor="#7e8493"
          value={userPhone}
          onChangeText={setUserPhone}
          keyboardType="phone-pad"
        />
      </View>
    </View>
  );
}
