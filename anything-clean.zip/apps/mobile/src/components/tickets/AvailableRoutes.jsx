import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { Clock } from "lucide-react-native";

export function AvailableRoutes({ routes, onBookTicket }) {
  if (routes.length === 0) {
    return null;
  }

  return (
    <View
      style={{
        backgroundColor: "#ffffff",
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "#E5E8EC",
        padding: 20,
        marginBottom: 20,
      }}
    >
      <Text
        style={{
          fontFamily: "Poppins_500Medium",
          fontSize: 18,
          color: "#202226",
          marginBottom: 16,
        }}
      >
        Available Routes ({routes.length})
      </Text>

      {routes.map((route) => (
        <TouchableOpacity
          key={route.id}
          style={{
            backgroundColor: "#F8F9FA",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            padding: 16,
            marginBottom: 12,
          }}
          onPress={() => onBookTicket(route)}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 8,
            }}
          >
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontFamily: "Poppins_600SemiBold",
                  fontSize: 16,
                  color: "#004a53",
                  marginBottom: 4,
                }}
              >
                {route.route_number} - {route.route_name}
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                {route.operator_name} • {route.bus_type}
              </Text>
            </View>
            <View style={{ alignItems: "flex-end" }}>
              <Text
                style={{
                  fontFamily: "Poppins_700Bold",
                  fontSize: 18,
                  color: "#004a53",
                  marginBottom: 4,
                }}
              >
                ₹{route.fare}
              </Text>
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 12,
                  color: "#7e8493",
                }}
              >
                per seat
              </Text>
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 12,
                color: "#7e8493",
              }}
            >
              {route.source_name} → {route.destination_name}
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 4,
              }}
            >
              <Clock size={12} color="#7e8493" />
              <Text
                style={{
                  fontFamily: "Poppins_400Regular",
                  fontSize: 12,
                  color: "#7e8493",
                }}
              >
                {route.duration_minutes}min
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      ))}
    </View>
  );
}
