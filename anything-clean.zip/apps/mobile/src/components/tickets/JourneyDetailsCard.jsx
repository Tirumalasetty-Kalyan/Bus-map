import React from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import { MapPin, Calendar, Search } from "lucide-react-native";

export function JourneyDetailsCard({
  fromLocation,
  setFromLocation,
  toLocation,
  setToLocation,
  journeyDate,
  setJourneyDate,
  onSearch,
  loading,
}) {
  return (
    <View
      style={{
        backgroundColor: "#ffffff",
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "#E5E8EC",
        padding: 20,
        marginBottom: 20,
      }}
    >
      <Text
        style={{
          fontFamily: "Poppins_500Medium",
          fontSize: 18,
          color: "#202226",
          marginBottom: 16,
        }}
      >
        Journey Details
      </Text>

      <View style={{ marginBottom: 16 }}>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
            marginBottom: 8,
          }}
        >
          From
        </Text>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#F8F9FA",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            paddingHorizontal: 16,
            paddingVertical: 12,
          }}
        >
          <MapPin size={20} color="#7e8493" />
          <TextInput
            style={{
              flex: 1,
              marginLeft: 12,
              fontFamily: "Poppins_400Regular",
              fontSize: 16,
              color: "#202226",
            }}
            placeholder="Enter departure location"
            placeholderTextColor="#7e8493"
            value={fromLocation}
            onChangeText={setFromLocation}
          />
        </View>
      </View>

      <View style={{ marginBottom: 16 }}>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
            marginBottom: 8,
          }}
        >
          To
        </Text>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#F8F9FA",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            paddingHorizontal: 16,
            paddingVertical: 12,
          }}
        >
          <MapPin size={20} color="#7e8493" />
          <TextInput
            style={{
              flex: 1,
              marginLeft: 12,
              fontFamily: "Poppins_400Regular",
              fontSize: 16,
              color: "#202226",
            }}
            placeholder="Enter destination"
            placeholderTextColor="#7e8493"
            value={toLocation}
            onChangeText={setToLocation}
          />
        </View>
      </View>

      <View style={{ marginBottom: 20 }}>
        <Text
          style={{
            fontFamily: "Poppins_400Regular",
            fontSize: 14,
            color: "#7e8493",
            marginBottom: 8,
          }}
        >
          Journey Date
        </Text>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#F8F9FA",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#E5E8EC",
            paddingHorizontal: 16,
            paddingVertical: 12,
          }}
        >
          <Calendar size={20} color="#7e8493" />
          <TextInput
            style={{
              flex: 1,
              marginLeft: 12,
              fontFamily: "Poppins_400Regular",
              fontSize: 16,
              color: "#202226",
            }}
            placeholder="YYYY-MM-DD"
            placeholderTextColor="#7e8493"
            value={journeyDate}
            onChangeText={setJourneyDate}
          />
        </View>
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: "#004a53",
          borderRadius: 8,
          paddingVertical: 16,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: 8,
        }}
        onPress={onSearch}
        disabled={loading}
      >
        <Search size={20} color="#ffffff" />
        <Text
          style={{
            fontFamily: "Poppins_500Medium",
            fontSize: 16,
            color: "#ffffff",
          }}
        >
          {loading ? "Searching..." : "Search Routes"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}
