import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  Alert,
  Dimensions,
} from "react-native";
import Svg, { Rect } from "react-native-svg";
import {
  X,
  Share2,
  Download,
  QrCode,
} from "lucide-react-native";

const { width } = Dimensions.get('window');

// Simple QR Code component using SVG
const QRCodeDisplay = ({ value, size = 200 }) => {
  const generateQRPattern = (data) => {
    // Simple QR-like pattern generator for demo
    const gridSize = 25;
    const cellSize = size / gridSize;
    const patterns = [];
    
    const hash = data.split('').reduce((acc, char) => {
      return char.charCodeAt(0) + ((acc << 5) - acc);
    }, 0);
    
    for (let row = 0; row < gridSize; row++) {
      for (let col = 0; col < gridSize; col++) {
        const pattern = (hash + row * gridSize + col) % 4;
        if (pattern === 0 || pattern === 1) {
          patterns.push(
            <Rect
              key={`${row}-${col}`}
              x={col * cellSize}
              y={row * cellSize}
              width={cellSize}
              height={cellSize}
              fill="#000000"
            />
          );
        }
      }
    }
    
    return patterns;
  };

  return (
    <View style={{ 
      backgroundColor: '#ffffff',
      padding: 16,
      borderRadius: 12,
      alignItems: 'center',
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    }}>
      <Svg height={size} width={size} viewBox={`0 0 ${size} ${size}`}>
        <Rect x={0} y={0} width={size} height={size} fill="#ffffff" />
        {generateQRPattern(value)}
      </Svg>
      <Text style={{
        fontFamily: "Poppins_400Regular",
        fontSize: 12,
        color: "#7e8493",
        marginTop: 8,
        textAlign: 'center'
      }}>
        Scan QR code for ticket verification
      </Text>
    </View>
  );
};

export function QRCodeModal({ visible, ticket, onClose }) {
  if (!ticket) return null;

  const qrData = JSON.stringify({
    ticketNumber: ticket.ticket_number,
    passengerName: ticket.user_name,
    phone: ticket.user_phone,
    route: `${ticket.route_number} - ${ticket.route_name}`,
    from: ticket.source_stop_name,
    to: ticket.dest_stop_name,
    date: ticket.journey_date,
    time: ticket.journey_time,
    fare: ticket.total_fare,
    operator: ticket.operator_name,
    status: ticket.booking_status
  });

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          justifyContent: "center",
          alignItems: "center",
          paddingHorizontal: 20,
        }}
      >
        <View
          style={{
            backgroundColor: "#ffffff",
            borderRadius: 20,
            padding: 20,
            width: "100%",
            maxWidth: 350,
            alignItems: "center",
          }}
        >
          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins_600SemiBold",
                fontSize: 18,
                color: "#202226",
              }}
            >
              🎫 Your Ticket
            </Text>
            <TouchableOpacity
              onPress={onClose}
              style={{
                backgroundColor: "#F8F9FA",
                borderRadius: 20,
                padding: 8,
              }}
            >
              <X size={20} color="#7e8493" />
            </TouchableOpacity>
          </View>

          {/* Ticket Info */}
          <View
            style={{
              backgroundColor: "#F8F9FA",
              borderRadius: 12,
              padding: 16,
              width: "100%",
              marginBottom: 20,
            }}
          >
            <Text
              style={{
                fontFamily: "Poppins_600SemiBold",
                fontSize: 16,
                color: "#004a53",
                marginBottom: 8,
                textAlign: "center",
              }}
            >
              {ticket.route_number} - {ticket.route_name}
            </Text>
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 14,
                color: "#202226",
                textAlign: "center",
                marginBottom: 4,
              }}
            >
              👤 {ticket.user_name}
            </Text>
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 14,
                color: "#202226",
                textAlign: "center",
                marginBottom: 4,
              }}
            >
              📱 {ticket.user_phone}
            </Text>
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 12,
                color: "#7e8493",
                textAlign: "center",
                marginBottom: 8,
              }}
            >
              🎫 {ticket.ticket_number}
            </Text>
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 12,
                color: "#7e8493",
                textAlign: "center",
                marginBottom: 4,
              }}
            >
              📍 {ticket.source_stop_name} → {ticket.dest_stop_name}
            </Text>
            <Text
              style={{
                fontFamily: "Poppins_400Regular",
                fontSize: 12,
                color: "#7e8493",
                textAlign: "center",
                marginBottom: 4,
              }}
            >
              📅 {new Date(ticket.journey_date).toLocaleDateString()} • ⏰ {ticket.journey_time}
            </Text>
            <Text
              style={{
                fontFamily: "Poppins_700Bold",
                fontSize: 16,
                color: "#004a53",
                textAlign: "center",
              }}
            >
              💰 ₹{ticket.total_fare}
            </Text>
          </View>

          {/* QR Code */}
          <QRCodeDisplay 
            value={qrData} 
            size={200}
          />

          {/* Actions */}
          <View
            style={{
              flexDirection: "row",
              gap: 12,
              marginTop: 20,
              width: "100%",
            }}
          >
            <TouchableOpacity
              style={{
                flex: 1,
                backgroundColor: "#F8F9FA",
                borderRadius: 8,
                paddingVertical: 12,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
              }}
              onPress={() => {
                Alert.alert("Share Ticket", "Share functionality coming soon!");
              }}
            >
              <Share2 size={16} color="#7e8493" />
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 14,
                  color: "#7e8493",
                }}
              >
                Share
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                flex: 1,
                backgroundColor: "#004a53",
                borderRadius: 8,
                paddingVertical: 12,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
              }}
              onPress={() => {
                Alert.alert("Download", "Download functionality coming soon!");
              }}
            >
              <Download size={16} color="#ffffff" />
              <Text
                style={{
                  fontFamily: "Poppins_500Medium",
                  fontSize: 14,
                  color: "#ffffff",
                }}
              >
                Save
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}