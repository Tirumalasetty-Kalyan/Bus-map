import { useState, useEffect } from "react";
import { Alert } from "react-native";

export function useTickets(activeTab) {
  const [fromLocation, setFromLocation] = useState("");
  const [toLocation, setToLocation] = useState("");
  const [journeyDate, setJourneyDate] = useState("");
  const [userName, setUserName] = useState("");
  const [userPhone, setUserPhone] = useState("");
  const [routes, setRoutes] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activeTab === "history" && userPhone) {
      fetchBookingHistory();
    }
  }, [activeTab, userPhone]);

  const searchRoutes = async () => {
    if (!fromLocation || !toLocation) {
      Alert.alert("Error", "Please enter both from and to locations");
      return;
    }
    setLoading(true);
    try {
      const response = await fetch(
        `/api/routes/search?from=${encodeURIComponent(
          fromLocation
        )}&to=${encodeURIComponent(toLocation)}`
      );
      const data = await response.json();
      if (data.success) {
        setRoutes(data.routes);
      } else {
        Alert.alert("Error", data.error);
      }
    } catch (error) {
      console.error("Error searching routes:", error);
      Alert.alert("Error", "Failed to search routes");
    } finally {
      setLoading(false);
    }
  };

  const bookTicket = async (route) => {
    if (!userName || !userPhone || !journeyDate) {
      Alert.alert("Error", "Please fill in all required details");
      return false;
    }
    setLoading(true);
    try {
      const response = await fetch("/api/tickets/book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userName,
          userPhone,
          routeId: route.id,
          sourceStopId: route.source_stop_id,
          destinationStopId: route.destination_stop_id,
          journeyDate,
          journeyTime: "06:00",
          seatsBooked: 1,
          paymentMethod: "Cash",
        }),
      });
      const data = await response.json();
      if (data.success) {
        Alert.alert(
          "Success",
          `Ticket booked successfully! Ticket Number: ${data.booking.ticket_number}`
        );
        return true;
      } else {
        Alert.alert("Error", data.error);
        return false;
      }
    } catch (error) {
      console.error("Error booking ticket:", error);
      Alert.alert("Error", "Failed to book ticket");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const fetchBookingHistory = async () => {
    if (!userPhone) return;
    setLoading(true);
    try {
      const response = await fetch(
        `/api/tickets/book?phone=${encodeURIComponent(userPhone)}`
      );
      const data = await response.json();
      if (data.success) {
        setBookings(data.bookings);
      } else {
        console.error("Error fetching bookings:", data.error);
      }
    } catch (error) {
      console.error("Error fetching bookings:", error);
    } finally {
      setLoading(false);
    }
  };

  return {
    fromLocation,
    setFromLocation,
    toLocation,
    setToLocation,
    journeyDate,
    setJourneyDate,
    userName,
    setUserName,
    userPhone,
    setUserPhone,
    routes,
    bookings,
    loading,
    searchRoutes,
    bookTicket,
    fetchBookingHistory,
  };
}
