import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const latitude = parseFloat(searchParams.get('latitude'));
    const longitude = parseFloat(searchParams.get('longitude'));
    const radius = parseFloat(searchParams.get('radius')) || 5; // Default 5km radius

    if (!latitude || !longitude) {
      return Response.json({ error: 'Latitude and longitude are required' }, { status: 400 });
    }

    // Find nearby bus stops using Haversine formula approximation
    const nearbyStops = await sql`
      SELECT 
        bs.*,
        (
          6371 * acos(
            cos(radians(${latitude})) * 
            cos(radians(bs.latitude)) * 
            cos(radians(bs.longitude) - radians(${longitude})) + 
            sin(radians(${latitude})) * 
            sin(radians(bs.latitude))
          )
        ) AS distance_km
      FROM bus_stops bs
      WHERE (
        6371 * acos(
          cos(radians(${latitude})) * 
          cos(radians(bs.latitude)) * 
          cos(radians(bs.longitude) - radians(${longitude})) + 
          sin(radians(${latitude})) * 
          sin(radians(bs.latitude))
        )
      ) <= ${radius}
      ORDER BY distance_km
      LIMIT 20
    `;

    // Get routes for each nearby stop
    const stopsWithRoutes = await Promise.all(
      nearbyStops.map(async (stop) => {
        const routes = await sql`
          SELECT DISTINCT br.route_number, br.route_name, br.operator_name, br.bus_type
          FROM bus_routes br
          JOIN route_stops rs ON br.id = rs.route_id
          WHERE rs.stop_id = ${stop.id}
          ORDER BY br.route_number
        `;

        const liveTracking = await sql`
          SELECT bt.bus_number, bt.estimated_arrival, bt.delay_minutes, bt.status, br.route_number
          FROM bus_tracking bt
          JOIN bus_routes br ON bt.route_id = br.id
          JOIN route_stops rs ON br.id = rs.route_id
          WHERE rs.stop_id = ${stop.id} AND bt.status = 'Running'
          ORDER BY bt.estimated_arrival
          LIMIT 5
        `;

        return {
          ...stop,
          routes,
          liveBuses: liveTracking
        };
      })
    );

    return Response.json({ 
      success: true, 
      stops: stopsWithRoutes 
    });

  } catch (error) {
    console.error('Error fetching nearby bus stops:', error);
    return Response.json({ error: 'Failed to fetch nearby bus stops' }, { status: 500 });
  }
}