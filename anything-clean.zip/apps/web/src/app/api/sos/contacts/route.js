import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const location = searchParams.get('location') || 'All India';

    const contacts = await sql`
      SELECT * FROM emergency_contacts 
      WHERE is_active = true 
      AND (location = ${location} OR location = 'All India')
      ORDER BY contact_type, name
    `;

    return Response.json({ 
      success: true, 
      contacts 
    });

  } catch (error) {
    console.error('Error fetching emergency contacts:', error);
    return Response.json({ error: 'Failed to fetch emergency contacts' }, { status: 500 });
  }
}