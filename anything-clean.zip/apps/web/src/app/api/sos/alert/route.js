import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { 
      userName, 
      userPhone, 
      latitude, 
      longitude, 
      locationAddress, 
      alertType = 'Emergency', 
      message 
    } = body;

    if (!userPhone || !latitude || !longitude) {
      return Response.json({ error: 'Phone, latitude, and longitude are required' }, { status: 400 });
    }

    // Create SOS alert
    const alert = await sql`
      INSERT INTO sos_alerts (
        user_name, user_phone, latitude, longitude, location_address, alert_type, message
      )
      VALUES (
        ${userName}, ${userPhone}, ${latitude}, ${longitude}, ${locationAddress}, ${alertType}, ${message}
      )
      RETURNING *
    `;

    return Response.json({ 
      success: true, 
      alert: alert[0],
      message: 'SOS alert sent successfully'
    });

  } catch (error) {
    console.error('Error creating SOS alert:', error);
    return Response.json({ error: 'Failed to send SOS alert' }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const phone = searchParams.get('phone');

    let alerts;
    if (phone) {
      alerts = await sql`
        SELECT * FROM sos_alerts 
        WHERE user_phone = ${phone}
        ORDER BY created_at DESC
      `;
    } else {
      alerts = await sql`
        SELECT * FROM sos_alerts 
        ORDER BY created_at DESC
        LIMIT 50
      `;
    }

    return Response.json({ 
      success: true, 
      alerts 
    });

  } catch (error) {
    console.error('Error fetching SOS alerts:', error);
    return Response.json({ error: 'Failed to fetch SOS alerts' }, { status: 500 });
  }
}