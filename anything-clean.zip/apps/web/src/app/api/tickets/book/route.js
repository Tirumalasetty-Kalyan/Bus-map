import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { 
      userName, 
      userPhone, 
      routeId, 
      sourceStopId, 
      destinationStopId, 
      journeyDate, 
      journeyTime, 
      seatsBooked = 1, 
      paymentMethod = 'Cash' 
    } = body;

    if (!userName || !userPhone || !routeId || !sourceStopId || !destinationStopId || !journeyDate || !journeyTime) {
      return Response.json({ error: 'All required fields must be provided' }, { status: 400 });
    }

    // Get route and fare information
    const routeInfo = await sql`
      SELECT br.*, 
             source_rs.fare_from_source as source_fare,
             dest_rs.fare_from_source as dest_fare
      FROM bus_routes br
      LEFT JOIN route_stops source_rs ON br.id = source_rs.route_id AND source_rs.stop_id = ${sourceStopId}
      LEFT JOIN route_stops dest_rs ON br.id = dest_rs.route_id AND dest_rs.stop_id = ${destinationStopId}
      WHERE br.id = ${routeId}
    `;

    if (routeInfo.length === 0) {
      return Response.json({ error: 'Route not found' }, { status: 404 });
    }

    const route = routeInfo[0];
    
    // Calculate fare based on intermediate stops
    let totalFare;
    if (route.source_fare !== null && route.dest_fare !== null) {
      totalFare = (route.dest_fare - route.source_fare) * seatsBooked;
    } else {
      totalFare = route.fare * seatsBooked;
    }

    // Generate unique ticket number
    const ticketNumber = `TKT${Date.now()}${Math.floor(Math.random() * 1000)}`;

    // Create booking
    const booking = await sql`
      INSERT INTO ticket_bookings (
        user_name, user_phone, route_id, source_stop_id, destination_stop_id,
        journey_date, journey_time, seats_booked, total_fare, ticket_number, payment_method
      )
      VALUES (
        ${userName}, ${userPhone}, ${routeId}, ${sourceStopId}, ${destinationStopId},
        ${journeyDate}, ${journeyTime}, ${seatsBooked}, ${totalFare}, ${ticketNumber}, ${paymentMethod}
      )
      RETURNING *
    `;

    // Get complete booking details with stop names
    const completeBooking = await sql`
      SELECT 
        tb.*,
        br.route_number, br.route_name, br.operator_name,
        source_stop.name as source_stop_name, source_stop.city as source_city,
        dest_stop.name as dest_stop_name, dest_stop.city as dest_city
      FROM ticket_bookings tb
      JOIN bus_routes br ON tb.route_id = br.id
      JOIN bus_stops source_stop ON tb.source_stop_id = source_stop.id
      JOIN bus_stops dest_stop ON tb.destination_stop_id = dest_stop.id
      WHERE tb.id = ${booking[0].id}
    `;

    return Response.json({ 
      success: true, 
      booking: completeBooking[0],
      message: 'Ticket booked successfully'
    });

  } catch (error) {
    console.error('Error booking ticket:', error);
    return Response.json({ error: 'Failed to book ticket' }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const phone = searchParams.get('phone');

    if (!phone) {
      return Response.json({ error: 'Phone number is required' }, { status: 400 });
    }

    const bookings = await sql`
      SELECT 
        tb.*,
        br.route_number, br.route_name, br.operator_name,
        source_stop.name as source_stop_name, source_stop.city as source_city,
        dest_stop.name as dest_stop_name, dest_stop.city as dest_city
      FROM ticket_bookings tb
      JOIN bus_routes br ON tb.route_id = br.id
      JOIN bus_stops source_stop ON tb.source_stop_id = source_stop.id
      JOIN bus_stops dest_stop ON tb.destination_stop_id = dest_stop.id
      WHERE tb.user_phone = ${phone}
      ORDER BY tb.created_at DESC
    `;

    return Response.json({ 
      success: true, 
      bookings 
    });

  } catch (error) {
    console.error('Error fetching bookings:', error);
    return Response.json({ error: 'Failed to fetch bookings' }, { status: 500 });
  }
}