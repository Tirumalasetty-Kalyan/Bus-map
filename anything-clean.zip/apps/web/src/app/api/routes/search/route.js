import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const from = searchParams.get('from');
    const to = searchParams.get('to');

    if (!from || !to) {
      return Response.json({ error: 'From and to parameters are required' }, { status: 400 });
    }

    // Search for routes between source and destination
    const routes = await sql`
      SELECT 
        br.*,
        source_stop.name as source_name,
        dest_stop.name as destination_name,
        source_stop.city as source_city,
        dest_stop.city as destination_city
      FROM bus_routes br
      JOIN bus_stops source_stop ON br.source_stop_id = source_stop.id
      JOIN bus_stops dest_stop ON br.destination_stop_id = dest_stop.id
      WHERE 
        (LOWER(source_stop.name) LIKE LOWER(${'%' + from + '%'}) OR 
         LOWER(source_stop.city) LIKE LOWER(${'%' + from + '%'}))
        AND 
        (LOWER(dest_stop.name) LIKE LOWER(${'%' + to + '%'}) OR 
         LOWER(dest_stop.city) LIKE LOWER(${'%' + to + '%'}))
      ORDER BY br.fare ASC
    `;

    // Get detailed route information for each route
    const routesWithDetails = await Promise.all(
      routes.map(async (route) => {
        const stops = await sql`
          SELECT 
            bs.name, bs.latitude, bs.longitude, bs.stop_code,
            rs.stop_order, rs.arrival_time, rs.departure_time, rs.fare_from_source
          FROM route_stops rs
          JOIN bus_stops bs ON rs.stop_id = bs.id
          WHERE rs.route_id = ${route.id}
          ORDER BY rs.stop_order
        `;

        const liveTracking = await sql`
          SELECT 
            bt.bus_number, bt.current_latitude, bt.current_longitude,
            bt.estimated_arrival, bt.delay_minutes, bt.status,
            current_stop.name as current_stop_name,
            next_stop.name as next_stop_name
          FROM bus_tracking bt
          LEFT JOIN bus_stops current_stop ON bt.current_stop_id = current_stop.id
          LEFT JOIN bus_stops next_stop ON bt.next_stop_id = next_stop.id
          WHERE bt.route_id = ${route.id} AND bt.status IN ('Running', 'Delayed')
          ORDER BY bt.estimated_arrival
        `;

        return {
          ...route,
          stops,
          liveBuses: liveTracking
        };
      })
    );

    return Response.json({ 
      success: true, 
      routes: routesWithDetails 
    });

  } catch (error) {
    console.error('Error searching routes:', error);
    return Response.json({ error: 'Failed to search routes' }, { status: 500 });
  }
}